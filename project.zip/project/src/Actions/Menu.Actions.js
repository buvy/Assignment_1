
export function fetchData() {
    return dispatch => {
//         fetch('http://texpertise.in/data.php')
        fetch('/mock.json')
        .then(results => {
            console.log(results);
            return results.json();
        })
        .then(response => {
            dispatch({ type: "FETCH_SUCCESS", response})
            console.log(response, "response");
        });
    }
} 